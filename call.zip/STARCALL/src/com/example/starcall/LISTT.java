package com.example.starcall;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class LISTT extends Activity {
	ListView v;
	static String g,k;
	static String data[]={"police" +
			"","kashish","jayesh","akash","avinash","sita","gita","bundal","hot","cold","nobita"};


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_listt);
		v=(ListView)findViewById(R.id.listView1);
		ArrayAdapter<String> ar=new ArrayAdapter<String>( LISTT.this,android.R.layout.simple_dropdown_item_1line,data);
		v.setAdapter(ar);
	
	v.setOnItemClickListener(new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// TODO Auto-generated method stub
			
			
			String rd=(String)arg0.getItemAtPosition(arg2);
			Toast.makeText( LISTT.this,"You have selected:" +rd, Toast.LENGTH_LONG).show();
			Intent i=new Intent(LISTT.this,CALL.class);
			startActivity(i);
			
			// TODO Auto-generated method stub
			if(rd.equalsIgnoreCase("police"))
			{
				g="100";
			}
			if(rd.equalsIgnoreCase("kashish"))
			{
				g="9829291996";
			}
			if(rd.equalsIgnoreCase("jayesh"))
			{
				g="8003939494";
			}
			if(rd.equalsIgnoreCase("akash"))
			{
				g="7742824277";
			}
			if(rd.equalsIgnoreCase("avinash"))
			{
				g="7877997690";
			}
			if(rd.equalsIgnoreCase("sita"))
			{
				g="7073935914";
			}if(rd.equalsIgnoreCase("gita"))
			{
				g="9352699972";
							}
			if(rd.equalsIgnoreCase("bundal"))
			{
				g="8560031845";
			}
			if(rd.equalsIgnoreCase("hot"))
			{
				g="8769758385";
			}
			if(rd.equalsIgnoreCase("cold"))
			{
				g="7073935914";
			}
			if(rd.equalsIgnoreCase("nobita"))
			{
				g="9001758744";
			}
			
		}
	}
			);	
	
	
	
	
	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_listt, menu);
		return true;
	}

}
