package com.example.starcall;



import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;

import android.view.View;
import android.view.View.OnClickListener;

import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class CALL extends Activity {
	

	ImageButton b1,b2,b3,b4;
	Button  bt1;
	EditText t1;

     String k,r,g1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call);
        b1=(ImageButton)findViewById(R.id.imageButton3);
        b2=(ImageButton)findViewById(R.id.imageButton2);
        b3=(ImageButton)findViewById(R.id.imageButton1);
        t1=(EditText)findViewById(R.id.editText1);
       bt1=(Button)findViewById(R.id.button1);
       
       
       
          
        b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				 Intent i=new Intent(CALL.this, LISTT.class);
				    startActivity(i);
				// TODO Auto-generated method stub
				
			}
		}
        		
        		
        		
        		
        		
       );
        
        
        
        
        
         g1= LISTT.g;
        t1.setText(g1);  
     
       b2.setOnClickListener(new OnClickListener() {
    	   
    	   
          
			@Override
			public void onClick(View arg0) {
			
				if(t1.getText().length()==10){
				k=t1.getText().toString();   
			    	
		           r="tel:"+k;
				Intent i=new Intent(Intent.ACTION_CALL,Uri.parse(r));
				startActivity(i);
				// TODO Auto-generated method stub
				}
				else
				{
					Toast.makeText(CALL.this,"Please enter valid number", Toast.LENGTH_SHORT).show();
				}
			}
		});
        
   b3.setOnClickListener(new OnClickListener() {
	
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
			if(t1.getText().length()!=0){
			String text=t1.getText().toString();
			t1.setText(text.substring(0,text.length()-1));
			}
			else
			{
				Toast.makeText(CALL.this,"please enter number first", Toast.LENGTH_SHORT).show();
			}
			
			
		
	}
});
   
   bt1.setOnClickListener(new OnClickListener() {
	
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
  	  Intent j=new Intent(CALL.this,abc.class);
		startActivity(j);
	}
}
		   
		   );
   }
      
}
